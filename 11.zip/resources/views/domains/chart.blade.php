
<div class="p-6 bg-white border-b border-gray-200">

    {{$domain->name}}

    <div>
        Minutes ago: <input type="text" id="minutes" value="1440"> <input id="submit" type="submit" value="submit">
    </div>
    
</div>



<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
    google.charts.load("current", {packages:["corechart"]});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {

        
        
        let chartHandler = () => {
            
            let minutes = document.getElementById('minutes');
            console.log('minutes', minutes.value);
            fetch('/curl-details/' + domainId, {
                method: "post",
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },

                //make sure to serialize your JSON body
                body: JSON.stringify({
                    minutes:minutes.value
                })
                
            }).then(res=>res.json()).then(data=>{
                console.log('data', data);

                let labels = Array(data.length).fill('');
                let online = 0;
                let offline = 0;
                let start = 0;


                data.forEach(item => {
                    if(item.status === "online"){
                        online++;
                    }else if(item.status === "offline"){
                        offline++;
                    }else if(item.status === "not_sent"){
                    }else{//if(item.status === "start")
                        start++;
                    }
                });

                var data = google.visualization.arrayToDataTable([
                    ['Status', 'Online or offline'],
                    ['Online', online],
                    ['Offline', offline],
                    ['Wait', start],
                ]);

                var options = {
                    title: 'Status',
                    pieHole: 0.4,
                };

                var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
                chart.draw(data, options);

            });
            let submitBtn = document.getElementById('submit');
            submitBtn.addEventListener('click', chartHandler);
            
        };
        
        chartHandler();
       
    }
</script>

<script>
    let domainId = "{{$domain->id}}";

    

</script>

<div id="donutchart" style="width: 900px; height: 500px;"></div>


